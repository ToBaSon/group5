package library__management__system;
import jframe.*;
/**
 *
 * @author Thang Ta
 */
public class Library__Management__System {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SignupPage page = new SignupPage();
        page.setVisible(true);
    }
    
}
