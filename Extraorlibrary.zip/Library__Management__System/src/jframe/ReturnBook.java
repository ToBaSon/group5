package jframe;
/**
 *
 * @author Thang Ta
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ReturnBook extends javax.swing.JFrame {

    public ReturnBook() {
        initComponents();
        setIssueInfoToTable();
        setReturnInfoToTable();
    }
    
    public void getRecordDetails() {
        int bookID = Integer.valueOf(BookID_box.getText());
        int studentID = Integer.valueOf(StudentID_box.getText());
        
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement pst = conn.prepareStatement("select * from issued_book_info where bookID = ? and studentID = ?");
            pst.setInt(1, bookID);
            pst.setInt(2, studentID);
           
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                bookID_box.setText(rs.getString("bookID"));
                title_box.setText(rs.getString("title"));
                studentID_box.setText(rs.getString("studentID"));
                name_box.setText(rs.getString("studentName"));
                issueDate_box.setText(rs.getString("issue_date"));
                dueDate_box.setText(rs.getString("due_date"));
            } else {
                JOptionPane.showMessageDialog(this, "Record NOT found");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public boolean returnBook() {
        int bookID = Integer.valueOf(bookID_box.getText());
        String title = title_box.getText();
        int studentID = Integer.valueOf(studentID_box.getText());
        String studentName = name_box.getText();
        String returnDate = new SimpleDateFormat("dd-MM-yyyy").format(Calendar.getInstance().getTime());
        
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement pst = conn.prepareStatement("insert into returned_book_info"
                    + "(bookID, title, studentID, studentName, returnDate) values (?,?,?,?,?)");
            
            pst.setInt(1, bookID);
            pst.setString(2, title);
            pst.setInt(3, studentID);
            pst.setString(4, studentName);
            pst.setString(5, returnDate);
            
            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean deleteIssueBook() {
        int bookID = Integer.valueOf(bookID_box.getText());
        int studentID = Integer.valueOf(studentID_box.getText());
        
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement pst = conn.prepareStatement("delete from issued_book_info where bookID = ? and studentID = ?");
            pst.setInt(1, bookID);
            pst.setInt(2, studentID);       
            int rowDeleted = pst.executeUpdate();
            if (rowDeleted > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }     
    public void plusBookCount() {
        int bookID = Integer.parseInt(bookID_box.getText());
        try {
            Connection con = DBConnection.getConnection();
            String sql = "update books_info set quantity = quantity + 1 where bookID = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, bookID);

            pst.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    // set return details from database into table 
    public void setIssueInfoToTable() {
        String studentName, title, issueDate, dueDate;
        int studentID, bookID;
        
        DefaultTableModel model;
        try {
            Connection conn = DBConnection.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from issued_book_info");
            
            while(rs.next()) {
                bookID = rs.getInt("bookID");
                title =rs.getString("title");
                studentID = rs.getInt("studentID");
                studentName = rs.getString("studentName");
                issueDate = rs.getString("issue_date");
                dueDate = rs.getString("due_date");
                
                Object[] obj = {bookID, title, studentID, studentName, issueDate, dueDate};
                model = (DefaultTableModel) table_issue.getModel();
                model.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void setReturnInfoToTable() {
        String studentName, title, returnDate;
        int studentID, bookID;
        
        DefaultTableModel model;
        try {
            Connection conn = DBConnection.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from returned_book_info");
            
            while(rs.next()) {
                bookID = rs.getInt("bookID");
                title =rs.getString("title");
                studentID = rs.getInt("studentID");
                studentName = rs.getString("studentName");
                returnDate = rs.getString("returnDate");
                
                Object[] obj = {bookID, title, studentID, studentName, returnDate};
                model = (DefaultTableModel) table_return.getModel();
                model.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void clearTable(){
        DefaultTableModel model1 = (DefaultTableModel) table_issue.getModel();
        model1.setRowCount(0);
        DefaultTableModel model2 = (DefaultTableModel) table_return.getModel();
        model2.setRowCount(0);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        roundButton2 = new jframe.RoundButton();
        jLabel19 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        BookID_box = new app.bolivia.swing.JCTextField();
        jLabel23 = new javax.swing.JLabel();
        StudentID_box = new app.bolivia.swing.JCTextField();
        jLabel24 = new javax.swing.JLabel();
        bookID_box = new app.bolivia.swing.JCTextField();
        jLabel25 = new javax.swing.JLabel();
        title_box = new app.bolivia.swing.JCTextField();
        jLabel28 = new javax.swing.JLabel();
        studentID_box = new app.bolivia.swing.JCTextField();
        jLabel29 = new javax.swing.JLabel();
        name_box = new app.bolivia.swing.JCTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_return = new rojerusan.RSTableMetro();
        jLabel32 = new javax.swing.JLabel();
        issueDate_box = new app.bolivia.swing.JCTextField();
        jLabel33 = new javax.swing.JLabel();
        dueDate_box = new app.bolivia.swing.JCTextField();
        roundButton3 = new jframe.RoundButton();
        jLabel26 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        table_issue = new rojerusan.RSTableMetro();
        jPanel3 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMinimumSize(new java.awt.Dimension(1000, 720));
        jPanel1.setPreferredSize(new java.awt.Dimension(1000, 720));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Dubai", 0, 30)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(22, 14, 78));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("X");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 10, 40, 40));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(22, 14, 78));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel6.setText("Return Book");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 220, 80));

        roundButton2.setBackground(new java.awt.Color(253, 206, 158));
        roundButton2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(22, 14, 78));
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("Find");
        jLabel19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel19MouseClicked(evt);
            }
        });
        roundButton2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 110, 40));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(22, 14, 78));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/NewIcon/zoom.png"))); // NOI18N
        jLabel22.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        roundButton2.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 0, 30, 40));

        jPanel1.add(roundButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 110, 40));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(22, 14, 78));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel21.setText("Book ID");
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 100, 30));

        BookID_box.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 0, 0)));
        BookID_box.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BookID_boxActionPerformed(evt);
            }
        });
        jPanel1.add(BookID_box, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 150, 40));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(22, 14, 78));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel23.setText("Student ID");
        jPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 100, 30));

        StudentID_box.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 0, 0)));
        jPanel1.add(StudentID_box, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 150, 40));

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(22, 14, 78));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel24.setText("Book ID:");
        jPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 80, 30));

        bookID_box.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        bookID_box.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookID_boxActionPerformed(evt);
            }
        });
        jPanel1.add(bookID_box, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 410, 160, 30));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(22, 14, 78));
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel25.setText("Title:");
        jPanel1.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 450, 80, 30));

        title_box.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        title_box.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                title_boxActionPerformed(evt);
            }
        });
        jPanel1.add(title_box, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 450, 160, 30));

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(22, 14, 78));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel28.setText("Student ID:");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 490, 110, 30));

        studentID_box.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        studentID_box.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentID_boxActionPerformed(evt);
            }
        });
        jPanel1.add(studentID_box, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 490, 160, 30));

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(22, 14, 78));
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel29.setText("Name:");
        jPanel1.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 530, 80, 30));

        name_box.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        name_box.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                name_boxActionPerformed(evt);
            }
        });
        jPanel1.add(name_box, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 530, 160, 30));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));

        table_return.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Title", "Student ID", "Name", "Return Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table_return.setColorBackgoundHead(new java.awt.Color(251, 141, 115));
        table_return.setColorFilasBackgound2(new java.awt.Color(255, 255, 255));
        table_return.setFuenteFilas(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        table_return.setFuenteFilasSelect(new java.awt.Font("Segoe UI Semibold", 1, 12)); // NOI18N
        table_return.setFuenteHead(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        table_return.setRowHeight(30);
        jScrollPane1.setViewportView(table_return);
        if (table_return.getColumnModel().getColumnCount() > 0) {
            table_return.getColumnModel().getColumn(0).setResizable(false);
            table_return.getColumnModel().getColumn(0).setPreferredWidth(50);
            table_return.getColumnModel().getColumn(1).setResizable(false);
            table_return.getColumnModel().getColumn(2).setResizable(false);
            table_return.getColumnModel().getColumn(2).setPreferredWidth(50);
            table_return.getColumnModel().getColumn(3).setResizable(false);
            table_return.getColumnModel().getColumn(4).setResizable(false);
        }

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 380, 690, 330));

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(22, 14, 78));
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel32.setText("Issue date:");
        jPanel1.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 570, 90, 30));

        issueDate_box.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        issueDate_box.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                issueDate_boxActionPerformed(evt);
            }
        });
        jPanel1.add(issueDate_box, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 570, 160, 30));

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(22, 14, 78));
        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel33.setText("Due date:");
        jPanel1.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 610, 90, 30));

        dueDate_box.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        dueDate_box.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dueDate_boxActionPerformed(evt);
            }
        });
        jPanel1.add(dueDate_box, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 610, 160, 30));

        roundButton3.setBackground(new java.awt.Color(251, 141, 115));
        roundButton3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(22, 14, 78));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("Return");
        jLabel26.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel26MouseClicked(evt);
            }
        });
        roundButton3.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 90, 40));

        jPanel1.add(roundButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 290, 110, 40));

        jScrollPane2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));

        table_issue.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID", "Title", "Student ID", "Name", "Issue Date", "Due Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table_issue.setColorBackgoundHead(new java.awt.Color(251, 141, 115));
        table_issue.setColorFilasBackgound2(new java.awt.Color(255, 255, 255));
        table_issue.setFuenteFilas(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        table_issue.setFuenteFilasSelect(new java.awt.Font("Segoe UI Semibold", 1, 12)); // NOI18N
        table_issue.setFuenteHead(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        table_issue.setRowHeight(30);
        table_issue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table_issueMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(table_issue);
        if (table_issue.getColumnModel().getColumnCount() > 0) {
            table_issue.getColumnModel().getColumn(0).setResizable(false);
            table_issue.getColumnModel().getColumn(0).setPreferredWidth(50);
            table_issue.getColumnModel().getColumn(1).setResizable(false);
            table_issue.getColumnModel().getColumn(2).setResizable(false);
            table_issue.getColumnModel().getColumn(2).setPreferredWidth(50);
            table_issue.getColumnModel().getColumn(3).setResizable(false);
            table_issue.getColumnModel().getColumn(4).setResizable(false);
            table_issue.getColumnModel().getColumn(4).setPreferredWidth(30);
            table_issue.getColumnModel().getColumn(5).setResizable(false);
            table_issue.getColumnModel().getColumn(5).setPreferredWidth(30);
        }

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 80, 690, 290));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 1030, 720));

        jPanel3.setBackground(new java.awt.Color(238, 236, 236));
        jPanel3.setMinimumSize(new java.awt.Dimension(280, 720));
        jPanel3.setPreferredSize(new java.awt.Dimension(280, 720));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(238, 236, 236));
        jPanel6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(22, 14, 78));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/NewIcon/student.png"))); // NOI18N
        jLabel5.setText("   Manage Students");
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        jPanel6.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, 210, 50));

        jPanel3.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 250, 50));

        jPanel9.setBackground(new java.awt.Color(238, 236, 236));
        jPanel9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel9MouseClicked(evt);
            }
        });
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(22, 14, 78));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/NewIcon/home.png"))); // NOI18N
        jLabel9.setText("   Dashboard");
        jLabel9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        jPanel9.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, 210, 50));

        jPanel3.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 250, 50));

        jPanel8.setBackground(new java.awt.Color(238, 236, 236));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(22, 14, 78));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel8.setText("Features");
        jPanel8.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 140, 30));

        jPanel3.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 250, 50));

        jPanel10.setBackground(new java.awt.Color(238, 236, 236));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(22, 14, 78));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/NewIcon/home.png"))); // NOI18N
        jLabel10.setText("   Manage Books");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });
        jPanel10.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, 210, 50));

        jPanel3.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 250, 50));

        jPanel12.setBackground(new java.awt.Color(238, 236, 236));
        jPanel12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(22, 14, 78));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/NewIcon/return.png"))); // NOI18N
        jLabel12.setText("   Issue Book");
        jLabel12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });
        jPanel12.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, 210, 50));

        jPanel3.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 250, 50));

        jPanel13.setBackground(new java.awt.Color(251, 141, 115));
        jPanel13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(22, 14, 78));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/NewIcon/return.png"))); // NOI18N
        jLabel13.setText("   Return Book");
        jLabel13.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel13.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, 210, 50));

        jPanel3.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 350, 250, 50));

        jPanel14.setBackground(new java.awt.Color(238, 236, 236));
        jPanel14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(22, 14, 78));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/NewIcon/search.png"))); // NOI18N
        jLabel14.setText("   Search");
        jLabel14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });
        jPanel14.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, 210, 50));

        jPanel3.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 250, 50));

        jPanel15.setBackground(new java.awt.Color(253, 206, 158));
        jPanel15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel15MouseClicked(evt);
            }
        });
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(22, 14, 78));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("Log Out");
        jLabel15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });
        jPanel15.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 180, 30));

        jPanel3.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 670, 250, 50));

        jLabel18.setFont(new java.awt.Font("Brush Script MT", 0, 40)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(221, 119, 119));
        jLabel18.setText("Extraorlibrary");
        jPanel3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 190, 60));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 720));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        Dashboard home = new Dashboard();
        this.dispose();
        home.setVisible(true);
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked

    }//GEN-LAST:event_jLabel15MouseClicked

    private void jPanel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel9MouseClicked
        
    }//GEN-LAST:event_jPanel9MouseClicked

    private void jPanel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel15MouseClicked
        LoginPage loginPage = new LoginPage();
        this.dispose();
        loginPage.setVisible(true);
    }//GEN-LAST:event_jPanel15MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        ManageBooks manageBooks = new ManageBooks();
        this.dispose();
        manageBooks.setVisible(true);
    }//GEN-LAST:event_jLabel10MouseClicked

    private void bookID_boxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookID_boxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bookID_boxActionPerformed

    private void title_boxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_title_boxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_title_boxActionPerformed

    private void studentID_boxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentID_boxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentID_boxActionPerformed

    private void name_boxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_name_boxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_name_boxActionPerformed

    private void BookID_boxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BookID_boxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BookID_boxActionPerformed

    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
        getRecordDetails();
    }//GEN-LAST:event_jLabel19MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        ManageStudents manageStudents = new ManageStudents();
        this.dispose();
        manageStudents.setVisible(true);
    }//GEN-LAST:event_jLabel5MouseClicked

    private void issueDate_boxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_issueDate_boxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_issueDate_boxActionPerformed

    private void dueDate_boxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dueDate_boxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dueDate_boxActionPerformed

    private void jLabel26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel26MouseClicked
        if (returnBook() == true && deleteIssueBook() == true) {
                plusBookCount();
                clearTable();
                setIssueInfoToTable();
                setReturnInfoToTable();
        } else {
            JOptionPane.showMessageDialog(this, "Book is NOT returned");
        }        
    }//GEN-LAST:event_jLabel26MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        IssueBook issueBook = new IssueBook();
        this.dispose();
        issueBook.setVisible(true);
    }//GEN-LAST:event_jLabel12MouseClicked

    private void table_issueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table_issueMouseClicked
        int rowNum = table_issue.getSelectedRow();
        
        TableModel model = table_issue.getModel();
        
        bookID_box.setText(model.getValueAt(rowNum, 0).toString());
        title_box.setText(model.getValueAt(rowNum, 1).toString());
        studentID_box.setText(model.getValueAt(rowNum, 2).toString());
        name_box.setText(model.getValueAt(rowNum, 3).toString());
        issueDate_box.setText(model.getValueAt(rowNum, 2).toString());
        dueDate_box.setText(model.getValueAt(rowNum, 2).toString());
    }//GEN-LAST:event_table_issueMouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        SearchPage searchPage = new SearchPage();
        this.dispose();       
        searchPage.setVisible(true);
    }//GEN-LAST:event_jLabel14MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReturnBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReturnBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReturnBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReturnBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReturnBook().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private app.bolivia.swing.JCTextField BookID_box;
    private app.bolivia.swing.JCTextField StudentID_box;
    private app.bolivia.swing.JCTextField bookID_box;
    private app.bolivia.swing.JCTextField dueDate_box;
    private app.bolivia.swing.JCTextField issueDate_box;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private app.bolivia.swing.JCTextField name_box;
    private jframe.RoundButton roundButton2;
    private jframe.RoundButton roundButton3;
    private app.bolivia.swing.JCTextField studentID_box;
    private rojerusan.RSTableMetro table_issue;
    private rojerusan.RSTableMetro table_return;
    private app.bolivia.swing.JCTextField title_box;
    // End of variables declaration//GEN-END:variables
}
